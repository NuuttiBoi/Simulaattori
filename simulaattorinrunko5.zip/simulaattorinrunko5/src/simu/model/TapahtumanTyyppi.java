package simu.model;

// TODO:
// Tapahtumien tyypit määritellään simulointimallin vaatimusten perusteella
public enum TapahtumanTyyppi {
	ARR1,
	DEP1,
	DEP2,
	DEP3

}
